YveltLogs = {}

YveltLogs.Enable = true
YveltLogs.LogsWebhook = {
    ['report'] = 'WEBHOOK_ICI',
    ['note'] = 'WEBHOOK_ICI',
    ['actions'] = 'WEBHOOK_ICI',
    ['tp'] = 'WEBHOOK_ICI',
    ['spawnCar'] = 'WEBHOOK_ICI',
    ['message'] = 'WEBHOOK_ICI',
    ['ban'] = 'WEBHOOK_ICI',
    ['kick'] = 'WEBHOOK_ICI',
    ['jail'] = 'WEBHOOK_ICI',
    ['warn'] = 'WEBHOOK_ICI',
    ['give'] = 'WEBHOOK_ICI',
    ['staffmode'] = 'WEBHOOK_ICI',
}